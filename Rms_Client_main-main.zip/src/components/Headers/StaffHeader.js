import { Card, CardBody, CardTitle, Container, Row, Col } from "reactstrap";

const StaffHeader = () => {
  return (
    <>
      <div className="header pb-8 pt-5 pt-md-8" style={{
          background: '#033E3E'
        }}>
        <Container fluid>
          <div className="header-body">
          </div>
        </Container>
      </div>
    </>
  );
};

export default StaffHeader;
  