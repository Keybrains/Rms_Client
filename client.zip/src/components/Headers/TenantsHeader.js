import { Card, CardBody, CardTitle, Container, Row, Col } from "reactstrap";

const TenantsHeader = () => {
  return (
    <>
      <div className="header pb-8 pt-5 pt-md-8" style={{
          background: '#3B2F2F'
        }}>
        <Container fluid>
          <div className="header-body">
           
            
          </div>
        </Container>
      </div>
    </>
  );
};

export default TenantsHeader;
  